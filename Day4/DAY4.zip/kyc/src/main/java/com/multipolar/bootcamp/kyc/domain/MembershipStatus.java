package com.multipolar.bootcamp.kyc.domain;

public enum MembershipStatus {
    FREE,
    STANDARD,
    PREMIUM,
    VIP
}
