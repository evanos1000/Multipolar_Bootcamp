package com.multipolar.bootcamp.logging;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoggingApplicationTests {

	@Test
	void contextLoads() {
	}

}
